Here is my futuristic car design. 
https://3dhaupt.com/futuristic-car-game-ready-download/

I modeled, textured and rigged this car in 
Blender from 31.03.2012 to 13.04.2012.

https://3dhaupt.com/futuristic-car-game-ready-download/futuristic-car-work-in-progress-31-03-2012-13-04-2012/

3d preview on Sketchfab
https://sketchfab.com/models/hliAt7xc6YU2XjXh5G4lzmQwFmR

The concept was created by Piotr Kupsc.
https://www.artstation.com/piotrkupsc

Here are some cool projects where this car has found a use:

Futuristic Car painting contest
https://blog.sketchfab.com/futuristic-car-painting-contest-here-are-the-winners/

Kosmiczny Kowboj - Cyberpunkish city street
https://www.youtube.com/watch?v=zuNx8-ifnKA

First test for a racing game by rocco martino
https://www.youtube.com/watch?v=IkTkAzmdpj8

Short movie celflux by GemGfx.
https://www.youtube.com/watch?v=l8_Zg2l5y4k&feature=youtu.be

Test in Arma3 by ThrompTOH
https://www.youtube.com/watch?v=PVA3GzTDzFY
        
Test in Cloud Party
https://www.youtube.com/watch?v=9kz3ptyEUOA

 
Animated Yes
Rigged Yes
VR / AR / Low-poly Yes
Geometry Subdivision ready
Polygons 4,293
Vertices 4,448
Textures Yes
Materials Yes
UV Mapping Yes
Unwrapped UVs Mixed
Some cool projects where this car has found a use:
Futuristic Car painting contest on Sketchfab
Kosmiczny Kowboj - Cyberpunkish city street in Unreal
First test for a racing game by rocco martino
Test in Arma3 by ThrompTOH
Available formats:
OBJ (.obj) 4.21 MB
Alias/WaveFront Material (.mtl) 4.21 MB
3D Studio (.3ds) 4.16 MB
Autodesk FBX (.fbx) 246 KB
Collada (.dae) 4.37 MB
Blender 2.74 (.blend) (2 files) -
X3D (.x3d) 4.21 MB
 